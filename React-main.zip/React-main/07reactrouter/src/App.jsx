import './App.css'

function App() {
  return (
    <>
      <h1 className='bg-green-700'>ALO WORLD!!!</h1>
    </>
  )
}

export default App
